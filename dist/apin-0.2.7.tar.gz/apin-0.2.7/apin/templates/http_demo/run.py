"""
运行启动文件


"""
import apin

apin.run()

