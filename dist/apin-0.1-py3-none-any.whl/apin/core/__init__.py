
from .logger import Logger

log = Logger()
