"""
============================
Author:柠檬班-木森
Time:2021/3/1 20:19
E-mail:3247119728@qq.com
Company:湖南零檬信息技术有限公司
=======
"""
# import importlib
#
# func_tools = importlib.import_module('func_tools')
#
# res = getattr(func_tools,"rand_phone")
# print(res())

# import re
#
# s = 'F{func(${{name}},${{age}})}'
#
# res = re.search(r'F{(.*?)\((.*?)\)}', s)
# print(res)
# print(res.group(1))
#
# s_params = res.group(2)
# ss = re.findall(r'\${{.+?}}',s_params )
# print(ss)



